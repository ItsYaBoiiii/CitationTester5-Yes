/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package citationmachinetester;

/**
 *
 * @author zhuj2423
 */
public class CitationMachineTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CitationGUI g = new CitationGUI();
        g.setVisible(true);
    }
}
